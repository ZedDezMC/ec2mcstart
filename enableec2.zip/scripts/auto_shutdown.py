#!/usr/bin/env python3
"""
Minecraft Server Auto-Shutdown Monitor & Mode Manager
Tự động quản lý tắt VPS EC2 (Normal Mode) hoặc giữ liên tục (Dev Mode).
Hỗ trợ cả Service ngầm lẫn các câu lệnh CLI điều khiển từ xa.
"""

import sys
import os
import socket
import json
import struct
import time

# Cấu hình mặc định
CHECK_INTERVAL_SECONDS = 60   # Quét mỗi 60 giây
MAX_EMPTY_MINUTES = 30        # Tắt VPS sau 30 phút 0 người chơi (Normal Mode)
MC_SERVER_HOST = "127.0.0.1"
MC_SERVER_PORT = 25565

DEV_MODE_FILE = "/opt/mc-autoshutdown/DEV_MODE"

def unpack_varint(sock):
    data = 0
    for i in range(5):
        ordinal = sock.recv(1)
        if not ordinal:
            raise EOFError("Unexpected EOF")
        byte = ordinal[0]
        data |= (byte & 0x7F) << (7 * i)
        if not (byte & 0x80):
            return data
    raise ValueError("VarInt too big")

def pack_varint(d):
    o = bytearray()
    while True:
        b = d & 0x7F
        d >>= 7
        if d != 0:
            o.append(b | 0x80)
        else:
            o.append(b)
            break
    return bytes(o)

def get_online_players(host=MC_SERVER_HOST, port=MC_SERVER_PORT, timeout=5):
    """
    Kiểm tra số người chơi online qua protocol Minecraft Server List Ping (SLP)
    """
    # 1. Thử Handshake theo chuẩn Minecraft 1.7+ JSON SLP
    try:
        with socket.create_connection((host, port), timeout=timeout) as s:
            host_bytes = host.encode('utf-8')
            payload = pack_varint(0) + pack_varint(47) + pack_varint(len(host_bytes)) + host_bytes + struct.pack('>H', port) + pack_varint(1)
            s.sendall(pack_varint(len(payload)) + payload)
            s.sendall(pack_varint(1) + pack_varint(0))

            length = unpack_varint(s)
            packet_id = unpack_varint(s)
            json_len = unpack_varint(s)

            res_bytes = bytearray()
            while len(res_bytes) < json_len:
                chunk = s.recv(min(1024, json_len - len(res_bytes)))
                if not chunk:
                    break
                res_bytes.extend(chunk)

            parsed = json.loads(res_bytes.decode('utf-8'))
            return parsed['players']['online']
    except Exception:
        pass

    # 2. Fallback sang Legacy Ping (\xfe\x01) cho các phiên bản cũ
    try:
        with socket.create_connection((host, port), timeout=timeout) as s:
            s.sendall(b'\xfe\x01')
            resp = s.recv(1024)
            if resp and resp.startswith(b'\xff'):
                text = resp[3:].decode('utf-16be', errors='ignore')
                parts = text.split('\x00')
                if len(parts) >= 5:
                    return int(parts[4])
    except Exception:
        pass

    raise RuntimeError("Không thể kết nối tới Minecraft Server")

def is_dev_mode():
    return os.path.exists(DEV_MODE_FILE)

def set_dev_mode():
    os.makedirs(os.path.dirname(DEV_MODE_FILE), exist_ok=True)
    with open(DEV_MODE_FILE, 'w') as f:
        f.write(f"Dev mode enabled at {time.ctime()}\n")
    print("[DEV MODE] Da KICH HOAT Che do Dev Mode! (Tu dong tat VPS da bi VO HIEU HOA)", flush=True)

def set_normal_mode():
    if os.path.exists(DEV_MODE_FILE):
        try:
            os.remove(DEV_MODE_FILE)
        except Exception as e:
            print(f"[ERROR] Loi khi xoa file co DEV_MODE: {e}", flush=True)
            return False
    print("[NORMAL MODE] Da KICH HOAT Che do Normal Mode! (VPS se tu dong tat sau 30 phut 0 nguoi choi)", flush=True)
    return True

def print_status():
    mode = "DEV MODE" if is_dev_mode() else "NORMAL MODE"
    print(f"[STATUS] Current Mode: {mode}")
    print(f"[STATUS] Target Server: {MC_SERVER_HOST}:{MC_SERVER_PORT}")
    print(f"[STATUS] Limit: {MAX_EMPTY_MINUTES} phut 0 nguoi choi")
    try:
        players = get_online_players()
        print(f"[STATUS] Online Players: {players}")
    except Exception as e:
        print(f"[STATUS] Minecraft Status: Offline / Starting ({e})")

def handle_cli_args():
    if len(sys.argv) > 1:
        cmd = sys.argv[1].lower().strip('-')
        if cmd in ['dev', 'set-dev', 'devmode']:
            set_dev_mode()
            sys.exit(0)
        elif cmd in ['normal', 'set-normal', 'normalmode']:
            set_normal_mode()
            sys.exit(0)
        elif cmd in ['status', 'check', 'info']:
            print_status()
            sys.exit(0)
        elif cmd in ['help', 'h']:
            print("Cach su dung:")
            print("  python3 auto_shutdown.py status     - Kiem tra trang thai hien tai")
            print("  python3 auto_shutdown.py dev        - Bat Che do Dev Mode")
            print("  python3 auto_shutdown.py normal     - Bat Che do Normal Mode")
            sys.exit(0)

def main_daemon():
    empty_minutes = 0
    current_mode = "DEV" if is_dev_mode() else "NORMAL"

    print("==================================================", flush=True)
    print("Minecraft Server Auto-Shutdown Service Daemon", flush=True)
    print(f"Target: {MC_SERVER_HOST}:{MC_SERVER_PORT}", flush=True)
    print(f"Auto-Shutdown Limit: {MAX_EMPTY_MINUTES} phut", flush=True)
    print(f"Initial Mode: {current_mode} MODE", flush=True)
    print("==================================================", flush=True)

    while True:
        try:
            in_dev = is_dev_mode()
            new_mode = "DEV" if in_dev else "NORMAL"

            # Phát hiện khi có sự chuyển đổi Chế độ (Mode Transition)
            if new_mode != current_mode:
                current_mode = new_mode
                empty_minutes = 0
                print("\n" + "="*50, flush=True)
                print(f"CHUYEN DOI CHE DO CHAY: [ {current_mode} MODE ]", flush=True)
                print("="*50 + "\n", flush=True)

            if in_dev:
                # 1. DEV MODE: Giữ bộ đếm ở 0, không tự động tắt VPS
                empty_minutes = 0
                print("[DEV MODE] Server dang o Che do Dev - Tu dong tat VPS da VO HIEU HOA.", flush=True)
            else:
                # 2. NORMAL MODE: Giám sát số người chơi online
                try:
                    players = get_online_players(MC_SERVER_HOST, MC_SERVER_PORT)
                    if players == 0:
                        empty_minutes += 1
                        print(f"[NORMAL MODE] 0 nguoi choi online ({empty_minutes}/{MAX_EMPTY_MINUTES} phut).", flush=True)
                    else:
                        if empty_minutes > 0:
                            print(f"[NORMAL MODE] Co {players} nguoi choi online! Dat lai bo dem ve 0.", flush=True)
                        empty_minutes = 0

                    if empty_minutes >= MAX_EMPTY_MINUTES:
                        print("[NORMAL MODE] 0 nguoi choi trong 30 phut lien tuc! Dang tien hanh TAT VPS EC2...", flush=True)
                        os.system("sudo shutdown -h now")
                        break
                except Exception as e:
                    # Server chưa mở hoặc đang khởi động lại -> Tạm dừng không tăng bộ đếm
                    print(f"[NORMAL MODE] Minecraft Server chua san sang ({e}). Dang cho...", flush=True)

        except Exception as err:
            print(f"[ERROR] Loi khong xac dinh: {err}", flush=True)

        time.sleep(CHECK_INTERVAL_SECONDS)

if __name__ == "__main__":
    handle_cli_args()
    main_daemon()
